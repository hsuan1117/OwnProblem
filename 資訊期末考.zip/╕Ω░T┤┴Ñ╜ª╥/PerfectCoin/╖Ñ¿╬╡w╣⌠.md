# 極佳硬幣
## Description
   

## Input  Format
第一行有一個整數 N  
接下來 N 行會有兩個以空白間個的整數 a,b，代表有 a 個面額為 b 的硬幣。  
再來有一個數 Q，代表有 Q 筆詢問  
接下來的每 Q 行，分別代表一筆詢問。  
每筆詢問有一組 X,Y  

## Output Format
請判斷是否可以將所有硬幣分成兩堆，並且兩邊價值比為 X:Y，
如果可以，輸出 "YES"，否則輸出 "NO"(不包括引號)。(行尾換行)  

## Sample Input
  - **Sample Input #1**
  > 3
  > 2 15
  > 2 10 
  > 5 2
  > 3	  
  > 2 3
  > 1 1
  > 1 59
  
  - **Sample Input #2**
  > 3
  > 5 4
  > 6 7 
  > 3 5
  > 3	  
  > 2 3
  > 1 1
  > 1 59

  
## Sample Output
  - **Sample Output #1**
  > YES
  > YES
  > NO 
  
  - **Sample Output #2**
  
  
## Scoring 
  * 1  <= Cloud<sub>i</sub> <= 10 <sup>6</sup>
  * 10 <= N,Q <= 2*10<sup>4</sup>
  
| Subtask | Score | Constraints 
| ------- | ----- | -----------  
| 1       | 20    |  N,Q <= 100 , Cloud<sub>i</sub> <= 10
| 2       | 20    |  N,Q <= 1000 , Cloud<sub>i</sub> <= 1000
| 3       | 20    |  N,Q <= 10<sup>4</sup> 
| 4       | 20    |  N,Q <= 2*10<sup>4</sup> , Cloud<sub>i</sub> <= 10 <sup>4</sup>
| 5       | 20    | 題目範圍 

## Note
  * 能力指標: 陣列、動態規劃
  * 題目ID: PerfectCoin
  * 保證 X+Y 為所有硬幣價值總合的因數
  * 由於輸入頗大，請加入輸入優化 (參見下方範例程式碼)
```cpp
#include<iostream>
using namespace std;
int main(){
	ios::sync_with_stdio(0);cin.tie(0);
	
	return 0;
}
```

## Judging
run-time limit: 2000 ms  
memory limit: 60000000 byte  
測資數量: 5
